export const theme = {
  colors: {
    background: '#1a0b2e',
    text: '#ffffff',
    accent: '#d4af37',
  },
} as const;

