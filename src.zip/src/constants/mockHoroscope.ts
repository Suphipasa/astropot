export const MOCK_HOROSCOPE = {
  sign: "Scorpio (Akrep)",
  date: "2026-02-04",
  prediction:
    "Bugün sabrın, internet bağlantın kadar yavaş. Kimseye bulaşma, özellikle eski sevgiline. Venüs retrosu seni tuzağa düşürmeye çalışıyor, yeme bu numaraları.",
  mood: "Barut Fıçısı 💣",
  lucky_color: "Simsiyah",
  compatibility: "Yengeç (Maalesef)",
};
