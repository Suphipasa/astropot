export const ZODIAC_SIGNS = [
    { id: '1', name: 'Koç', icon: '♈', date: '21 Mart - 19 Nisan' },
    { id: '2', name: 'Boğa', icon: '♉', date: '20 Nisan - 20 Mayıs' },
    { id: '3', name: 'İkizler', icon: '♊', date: '21 Mayıs - 20 Haziran' },
    { id: '4', name: 'Yengeç', icon: '♋', date: '21 Haziran - 22 Temmuz' },
    { id: '5', name: 'Aslan', icon: '♌', date: '23 Temmuz - 22 Ağustos' },
    { id: '6', name: 'Başak', icon: '♍', date: '23 Ağustos - 22 Eylül' },
    { id: '7', name: 'Terazi', icon: '♎', date: '23 Eylül - 22 Ekim' },
    { id: '8', name: 'Akrep', icon: '♏', date: '23 Ekim - 21 Kasım' },
    { id: '9', name: 'Yay', icon: '♐', date: '22 Kasım - 21 Aralık' },
    { id: '10', name: 'Oğlak', icon: '♑', date: '22 Aralık - 19 Ocak' },
    { id: '11', name: 'Kova', icon: '♒', date: '20 Ocak - 18 Şubat' },
    { id: '12', name: 'Balık', icon: '♓', date: '19 Şubat - 20 Mart' },
  ];