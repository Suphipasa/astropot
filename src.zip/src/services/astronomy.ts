import { UserProfile, NatalChart } from '../types';

// @ts-ignore
const AstronomyLib = require('astronomy-engine');
const Astronomy = AstronomyLib.default || AstronomyLib;

const ZODIAC_SIGNS = [
  "Koç", "Boğa", "İkizler", "Yengeç", "Aslan", "Başak",
  "Terazi", "Akrep", "Yay", "Oğlak", "Kova", "Balık"
];

const getSignFromLongitude = (longitude: number): string | undefined => {
  if (longitude === undefined || isNaN(longitude)) return undefined;
  
  let lon = longitude % 360;
  if (lon < 0) lon += 360;
  const index = Math.floor(lon / 30);
  return ZODIAC_SIGNS[index % 12];
};

/**
 * 🛠️ J2000 -> TROPICAL (Güncel Ekinoks) Dönüşümü
 */
const getTropicalLongitude = (astroTime: any, vectorJ2000: any): number => {
  const precessionMatrix = Astronomy.Precession(Astronomy.J2000, astroTime);
  const vectorOfDate = Astronomy.RotateVector(precessionMatrix, vectorJ2000);
  const ecliptic = Astronomy.Ecliptic(vectorOfDate);
  return ecliptic.lon;
};

const calculateAscendant = (time: any, lat: number, lng: number): number => {
  if (!Astronomy.SiderealTime) return 0;
  
  const gmst = Astronomy.SiderealTime(time);
  const lmst = (gmst + lng / 15.0) % 24.0;
  const ramc = lmst * 15.0;
  
  let trueObliquity = 23.4392911;
  try {
     if (Astronomy.e_tilt) {
       const o = Astronomy.e_tilt(time);
       trueObliquity = (typeof o === 'number') ? o : (o?.obl || o?.total || trueObliquity);
     }
  } catch(e) {}
  
  const rad = (d: number) => (d * Math.PI) / 180.0;
  const deg = (r: number) => (r * 180.0) / Math.PI;
  
  const numerator = Math.cos(rad(ramc));
  const denominator = -Math.sin(rad(ramc)) * Math.cos(rad(trueObliquity)) - Math.tan(rad(lat)) * Math.sin(rad(trueObliquity));
  let asc = deg(Math.atan2(numerator, denominator));
  if (asc < 0) asc += 360;
  return asc;
};

export const calculateFullChart = (profile: UserProfile): NatalChart => {
  console.log("📍 Hesaplama Başladı (Raw Date): ", profile.birthDate);

  const AstroTime = Astronomy.AstroTime;
  
  let year, month, day;

  // --- TARİH FORMATI AYIKLAMA (ISO FIX) ---
  const dateStr = String(profile.birthDate); // String olduğundan emin olalım

  if (dateStr.includes('T')) {
    // FORMAT: 2001-12-13T06:20:00.000Z (ISO)
    // Sadece "2001-12-13" kısmını alıp işleyeceğiz
    const cleanDate = dateStr.split('T')[0];
    const parts = cleanDate.split('-');
    year = parseInt(parts[0], 10);
    month = parseInt(parts[1], 10);
    day = parseInt(parts[2], 10);
  } else if (dateStr.includes('.')) {
    // FORMAT: 13.12.2001 (DD.MM.YYYY)
    const parts = dateStr.split('.');
    day = parseInt(parts[0], 10);
    month = parseInt(parts[1], 10);
    year = parseInt(parts[2], 10);
  } else {
    // FORMAT: 2001-12-13 (YYYY-MM-DD)
    const parts = dateStr.split('-');
    year = parseInt(parts[0], 10);
    month = parseInt(parts[1], 10);
    day = parseInt(parts[2], 10);
  }

  // Saati ayrıca alıyoruz (Date objesindeki saat yerine kullanıcının seçtiği net saati kullanmak için)
  const [hours, minutes] = profile.birthTime.split(':').map(Number);

  console.log(`🛠️ Parsed Date: ${day}.${month}.${year} - Time: ${hours}:${minutes}`);

  // Tarih geçerli mi kontrol et
  if (isNaN(year) || isNaN(month) || isNaN(day)) {
    console.error("❌ Hala Geçersiz Tarih Formatı:", profile.birthDate);
    return { sunSign: "Hata", moonSign: "Hata", risingSign: "Hata" };
  }

  // UTC Tarih oluştur (Ay 0-indeksli olduğu için -1 yapıyoruz)
  // Bu yöntem gün atlamasını engeller.
  const dateObj = new Date(Date.UTC(year, month - 1, day, hours, minutes));
  
  // AstroTime nesnesini oluştur
  const astroTime = new AstroTime(dateObj);

  // --- HESAPLAMALAR ---
  const sunVector = Astronomy.GeoVector(Astronomy.Body.Sun, astroTime, true);
  const sunLon = getTropicalLongitude(astroTime, sunVector);

  const moonVector = Astronomy.GeoVector(Astronomy.Body.Moon, astroTime, true);
  const moonLon = getTropicalLongitude(astroTime, moonVector);

  const ascDegree = calculateAscendant(astroTime, profile.birthCity.lat, profile.birthCity.lng);
  
  console.log(`✅ HESAPLANDI -> Güneş: ${sunLon.toFixed(2)}, Ay: ${moonLon.toFixed(2)}, Yükselen: ${ascDegree.toFixed(2)}`);

  return {
    sunSign: getSignFromLongitude(sunLon) || "Bilinmiyor",
    moonSign: getSignFromLongitude(moonLon) || "Bilinmiyor",
    risingSign: getSignFromLongitude(ascDegree) || "Bilinmiyor"
  };
};