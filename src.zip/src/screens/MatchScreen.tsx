import React, { useState, useRef } from 'react';
import { 
  View, Text, TextInput, StyleSheet, TouchableOpacity, 
  ScrollView, ActivityIndicator, KeyboardAvoidingView, Platform 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { UserService } from '../services/user';
import { analyzeMatch, MatchResult } from '../services/ai';
import ViewShot from 'react-native-view-shot'; // EKLENDİ
import { shareContent } from '../services/sharing';

const ZODIAC_SIGNS = [
  "Koç", "Boğa", "İkizler", "Yengeç", 
  "Aslan", "Başak", "Terazi", "Akrep", 
  "Yay", "Oğlak", "Kova", "Balık"
];

export default function MatchScreen() {
  const [partnerName, setPartnerName] = useState("");
  const [selectedSign, setSelectedSign] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MatchResult | null>(null);
  const viewShotRef = useRef(null);

  const handleAnalyze = async () => {
    if (!partnerName || !selectedSign) return;
    
    setLoading(true);
    // Klavyeyi kapat
    
    try {
      const userProfile = await UserService.getProfile();
      if (userProfile) {
        const data = await analyzeMatch(userProfile, partnerName, selectedSign);
        setResult(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setPartnerName("");
    setSelectedSign("");
  };

  // --- SONUÇ EKRANI (RENDER) ---
  if (result) {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView contentContainerStyle={styles.centerContent}>
          <Text style={styles.headerTitle}>UYUM RAPORU 💘</Text>
          
          {/* FOTOĞRAF ALANI */}
          <ViewShot 
             ref={viewShotRef} 
             options={{ format: "png", quality: 1 }}
             style={{ backgroundColor: '#000', width: '100%', padding: 10, alignItems: 'center' }}
          >
              <LinearGradient 
                colors={result.score > 50 ? ['#059669', '#047857'] : ['#DC2626', '#991B1B']} 
                style={styles.scoreCard}
              >
                <Text style={styles.scoreLabel}>UYUM PUANI</Text>
                <Text style={styles.scoreValue}>%{result.score}</Text>
              </LinearGradient>

              <LinearGradient colors={['#4c1d95', '#2e1065']} style={styles.resultCard}>
                <Text style={styles.coupleName}>{result.coupleName}</Text>
                <View style={styles.divider} />
                <Text style={styles.roastText}>"{result.roast}"</Text>
                
                <View style={styles.flagBox}>
                  <Text style={styles.flagTitle}>🚩 RED FLAG:</Text>
                  <Text style={styles.flagText}>{result.redFlag}</Text>
                </View>
                {/* İmza */}
                <Text style={{color:'#888', textAlign:'right', marginTop:10, fontSize:10}}>Astropot 💘</Text>
              </LinearGradient>
          </ViewShot>

          {/* BUTONLAR */}
          <TouchableOpacity style={styles.shareBtn} onPress={() => shareContent(viewShotRef)}>
             <LinearGradient
                colors={['#833AB4', '#FD1D1D', '#FCB045']}
                start={{x: 0, y: 0}} end={{x: 1, y: 0}}
                style={styles.shareGradient}
              >
                <Text style={styles.shareBtnText}>📸 Rezilliği Paylaş</Text>
              </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity style={styles.resetBtn} onPress={handleReset}>
            <Text style={styles.resetText}>💔 Yeni Kurban Seç</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // --- GİRİŞ EKRANI (RENDER) ---
  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <Text style={styles.headerTitle}>AŞK METRE 🔥</Text>
          <Text style={styles.subtitle}>
            Partnerinin (veya platonik aşkının) adını ve burcunu gir, gerçekleri yüzüne vuralım.
          </Text>

          {/* İSİM GİRİŞİ */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Partnerin Adı</Text>
            <TextInput 
              style={styles.input} 
              placeholder="Örn: Eski Sevgilim" 
              placeholderTextColor="#666"
              value={partnerName}
              onChangeText={setPartnerName}
            />
          </View>

          {/* BURÇ SEÇİMİ */}
          <Text style={styles.label}>Partnerin Burcu</Text>
          <View style={styles.gridContainer}>
            {ZODIAC_SIGNS.map((sign) => (
              <TouchableOpacity 
                key={sign} 
                style={[
                  styles.signBtn, 
                  selectedSign === sign && styles.signBtnActive
                ]}
                onPress={() => setSelectedSign(sign)}
              >
                <Text style={[
                  styles.signText, 
                  selectedSign === sign && styles.signTextActive
                ]}>
                  {sign}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* BUTON */}
          <TouchableOpacity 
            style={[styles.analyzeBtn, (!partnerName || !selectedSign) && styles.disabledBtn]} 
            onPress={handleAnalyze}
            disabled={!partnerName || !selectedSign || loading}
          >
            {loading ? (
              <ActivityIndicator color="#000" />
            ) : (
              <Text style={styles.analyzeBtnText}>ANALİZ ET 🔮</Text>
            )}
          </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  scrollContent: { padding: 20 },
  centerContent: { padding: 20, alignItems: 'center', justifyContent: 'center', minHeight: '100%' },
  
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '900', textAlign: 'center', marginBottom: 10, letterSpacing: 1 },
  subtitle: { color: '#888', textAlign: 'center', marginBottom: 30, fontSize: 14 },
  
  inputGroup: { marginBottom: 25, width: '100%' },
  label: { color: '#A855F7', marginBottom: 10, fontSize: 14, fontWeight: 'bold' },
  input: { 
    backgroundColor: '#111', borderWidth: 1, borderColor: '#333', 
    borderRadius: 12, padding: 15, color: '#fff', fontSize: 16 
  },

  gridContainer: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 30 },
  signBtn: { 
    width: '30%', backgroundColor: '#111', borderWidth: 1, borderColor: '#333',
    borderRadius: 10, paddingVertical: 12, marginBottom: 10, alignItems: 'center'
  },
  signBtnActive: { backgroundColor: '#A855F7', borderColor: '#A855F7' },
  signText: { color: '#888', fontWeight: '600' },
  signTextActive: { color: '#fff', fontWeight: 'bold' },

  analyzeBtn: { 
    backgroundColor: '#fff', borderRadius: 15, padding: 18, 
    alignItems: 'center', width: '100%', marginBottom: 50 
  },
  disabledBtn: { backgroundColor: '#333', opacity: 0.7 },
  analyzeBtnText: { color: '#000', fontWeight: '900', fontSize: 16 },

  // RESULT STYLES
  scoreCard: {
    width: 150, height: 150, borderRadius: 100,
    justifyContent: 'center', alignItems: 'center',
    marginBottom: 30, borderWidth: 4, borderColor: 'rgba(255,255,255,0.1)'
  },
  scoreLabel: { color: 'rgba(255,255,255,0.8)', fontSize: 12, fontWeight: 'bold' },
  scoreValue: { color: '#fff', fontSize: 42, fontWeight: '900' },

  resultCard: {
    width: '100%', borderRadius: 20, padding: 25, marginBottom: 30,
    borderWidth: 1, borderColor: '#A855F7'
  },
  coupleName: {fontSize: 22, fontWeight: '900', textAlign: 'center', marginBottom: 15, color: '#F472B6' },
  divider: { height: 1, backgroundColor: 'rgba(255,255,255,0.1)', marginBottom: 15 },
  roastText: { color: '#e9d5ff', fontSize: 16, lineHeight: 24, textAlign: 'center', fontStyle: 'italic', marginBottom: 20 },
  
  flagBox: { backgroundColor: 'rgba(0,0,0,0.3)', padding: 15, borderRadius: 10 },
  flagTitle: { color: '#EF4444', fontWeight: 'bold', fontSize: 12, marginBottom: 5 },
  flagText: { color: '#fff', fontWeight: '600' },

  resetBtn: { padding: 15 },
  resetText: { color: '#666', fontWeight: 'bold', textDecorationLine: 'underline' },

  brandSignature: {
    color: '#666', fontSize: 10, fontWeight: 'bold', 
    textAlign: 'right', marginTop: 10, fontStyle: 'italic'
  },
  shareBtn: { marginTop: 20, marginBottom: 50, alignItems: 'center' },
  shareGradient: {
    paddingVertical: 15, paddingHorizontal: 40, borderRadius: 30,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center'
  },
  shareBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 }
});